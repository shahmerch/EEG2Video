%% PA2 - Question 2: Initialization
addpath('mr')
[links, joints] = load_urdf('ur5.urdf');

%% Construction of transformation matrices at the home position



% The end-effector frame (the last "joint") configuration at the zero position
M = 


%% Construction of Slist
% We first formulate the screw axis in each joint frame, and then use
% adjoint matrix to compute the screw axes in the space frame

Slist = 



%% Task (a): Compute forward kinematics
th1 = zeros(1,6);
T1 = FKinSpace(M, Slist, th1); % homogeneous transformation 
[R1,p1] = TransToRp(T1) % extra the orientation (R) and position (p)
%NOTE: you can either report T1, or report (R1,p1) separately. 

th2 = [pi/3, pi/2, -pi/6,pi/4,pi/2,pi/3]';
T2 = FKinSpace(M, Slist, th2); % homogeneous transformation 
[R2,p2] = TransToRp(T2) % extra the orientation (R) and position (p)
%NOTE: you can either report T2, or report (R2,p2) separately. 

%% Task (b): Compute the position of the end-effector tip in the space frame.
pb = [-0.3;0.1;0.5];

pt1 =    % for th1 set of joint values
pt2 =    % for th2 set of joint values

%NOTE: you can also use the extended coordinates

