%% PA2 - Question 1: Initialization
% the followings are the constant given in the problem.
addpath('mr');
t = 4; 

omega1 = pi/4;
omega2 = pi/8;
omega3 = -pi/4;

L1 = 10;
L2 = 5;
L3 = 5;
L4 = 3;

h = 2;
%% Get the configuration at the zero position directly from the figure
% It can be determined by the coordinates of the body frame axes and origin
% in the space frame. 



%% Determine the screw axes in the space frame and then use FKinSpace



% Stack them to a 2D matrix, each column represent one screw axis.


% compute the joint angles at time t

% Use `FKinSpace` function to compute the forward kinematics
% Ts = FKinSpace()

%% Compare with the results from PA1
Ts_pa1 = [0 0 1 5
          1 0 0 -2
          0 1 0 10+2*pi
          0 0 0 1];

Ts - Ts_pa1
%% Determine the screw axes in the body frame {b} and then use FKinBody


% Stack them to a 2D matrix, each column represent one screw axis.


% compute the joint angles from time t

% Use FKinBody function to compute the forward kinematics
Tb = FKinBody(???)

%% Compare the results from FKinSpace and FKinBody

Ts - Tb