import mujoco
import numpy as np
import time
import pinocchio as pin
from scipy.linalg import solve_continuous_are 
import scipy.io
import os

# --- Parameters ---
vel_filter_alpha = 0.5  # Filter parameter (0.0-1.0)


# --- Control Computation ---
def compute_control(sim_time, data, model_pin, data_pin, t_vec, traj, traj_vel, traj_acc, prev_filtered_qdot=None):
    # Use all 6 joints.
    q = data.qpos[:].copy()
    qdot = data.qvel[:].copy()
    # Get filtered velocity
    filtered_qdot = filter_velocity(qdot, prev_filtered_qdot, vel_filter_alpha)
    
    # get desired trajectory
    q_des, qdot_des, qddot_des = compute_desired_trajectory(sim_time, t_vec, traj, traj_vel, traj_acc)

    # Compute error and error derivative    
    error = q - q_des
    error_dot = filtered_qdot - qdot_des
    
    # Compute dynamics using Pinocchio.
    zero_acc = np.zeros(6)
    M = np.array(pin.crba(model_pin, data_pin, q)) # mass matrix
    nle = np.array(pin.rnea(model_pin, data_pin, q, filtered_qdot, zero_acc)) # gravity and coriolis
    
    # TODO: Implement control computation
    u_ff = np.zeros(6)
    u_fb = np.zeros(6)

    # compute total control
    u_total = u_ff + u_fb
    return {
        "q": q,
        "qdot": filtered_qdot,
        "q_des": q_des,
        "qdot_des": qdot_des,
        "qddot_des": qddot_des,
        "error": error,
        "error_dot": error_dot,
        "u_fb": u_fb,
        "u_ff": u_ff,
        "u_total": u_total
    }

def load_trajectory(mat_file='joint_trajectories.mat'):
    if not os.path.exists(mat_file):
        raise FileNotFoundError(f".mat file not found: {mat_file}")
    mat_data = scipy.io.loadmat(mat_file)
    return mat_data['joint_trajectory']

def compute_derivatives(trajectory, dt_traj=0.1):
    dq = np.gradient(trajectory, dt_traj, axis=0)
    ddq = np.gradient(dq, dt_traj, axis=0)
    return dq, ddq

# --- Setup Simulation ---
def setup_simulation(q_init=np.zeros(6)):
    # Load models for simulation and dynamics computation.
    model = mujoco.MjModel.from_xml_path('model/scene.xml')
    data = mujoco.MjData(model)
    model_pin = pin.buildModelFromUrdf('model/ur5e.urdf')
    data_pin = model_pin.createData()
    # Set initial state (nearly horizontal configuration)    
    data.qpos[:] = q_init
    data.qvel[:] = np.zeros(6)
    mujoco.mj_forward(model, data)
    return model, data, model_pin, data_pin

# --- Desired Trajectory Interpolation ---
def compute_desired_trajectory(sim_time, t_vec, traj, traj_vel, traj_acc):
    nq = traj.shape[1]
    q_des = np.zeros(nq)
    qdot_des = np.zeros(nq)
    qddot_des = np.zeros(nq)
    for i in range(nq):
        q_des[i]    = np.interp(sim_time, t_vec, traj[:,i])
        qdot_des[i] = np.interp(sim_time, t_vec, traj_vel[:,i])
        qddot_des[i]= np.interp(sim_time, t_vec, traj_acc[:,i])
    return q_des, qdot_des, qddot_des



# --- Filtered velocity function ---
def filter_velocity(current_vel, previous_vel, alpha=0.5):
    """Apply a simple first-order filter to velocity signals.
    alpha = 1.0 means no filtering (use current_vel directly)
    alpha = 0.0 means ignore current_vel (keep previous_vel)
    """
    return alpha * current_vel + (1-alpha) * previous_vel



# --- Simulation and Logging ---
def simulate_and_log(model, data, model_pin, data_pin, t_vec, traj, traj_vel, traj_acc):
    n_steps = int(10 / model.opt.timestep)  # simulate for 10 sec
    nq = model.nq
    nu = model.nu
    recorded_data = {
        "time": np.zeros(n_steps),
        "joint_pos": np.zeros((n_steps, nq)),
        "joint_vel": np.zeros((n_steps, nq)),
        "joint_pos_des": np.zeros((n_steps, nq)),
        "joint_vel_des": np.zeros((n_steps, nq)),
        "u_ff": np.zeros((n_steps, nu)),
        "u_fb": np.zeros((n_steps, nu)),
        "u_total": np.zeros((n_steps, nu))
    }
    data_index = 0
    
    # Add variable to store filtered velocity between iterations
    filtered_velocity = np.zeros(6)
    
    with mujoco.viewer.launch_passive(model, data) as viewer:
        # Adjust camera.
        viewer.cam.lookat = np.array([0.0, 0.0, 0.25])
        viewer.cam.distance = 2.0
        viewer.cam.elevation = 0
        # input("Press Enter to start the simulation...")
        start_time = time.time()
        sim_time = 0.0  
        while sim_time < 10:
            elapsed = time.time() - start_time
            if elapsed < sim_time:
                time.sleep(sim_time - elapsed)
            
            # Update control with filtered velocity tracking
            control_components = compute_control(sim_time, data, model_pin, data_pin, 
                                              t_vec, traj, traj_vel, traj_acc, 
                                              filtered_velocity)
            
            # Store filtered velocity for next iteration
            filtered_velocity = control_components["qdot"]
            
            data.ctrl[:] = control_components["u_total"]
            
            if data_index < n_steps:
                recorded_data["time"][data_index] = data.time
                recorded_data["joint_pos"][data_index] = data.qpos.copy()
                recorded_data["joint_vel"][data_index] = data.qvel.copy()
                recorded_data["joint_pos_des"][data_index] = control_components["q_des"]
                recorded_data["joint_vel_des"][data_index] = control_components["qdot_des"]
                recorded_data["u_ff"][data_index] = control_components["u_ff"]
                recorded_data["u_fb"][data_index] = control_components["u_fb"]
                recorded_data["u_total"][data_index] = control_components["u_total"]
                data_index += 1
            mujoco.mj_step(model, data)
            viewer.sync()
            sim_time += model.opt.timestep
        # input("Press Enter to close the simulation...")
    return recorded_data

# --- Save Data ---
def save_logged_data(filename, recorded_data):
    np.savez(filename, **recorded_data)
    print(f"Simulation data saved to {filename}")

# --- Main Function ---
def main():
    # Load the trajectory and derivatives.
    traj = load_trajectory()  # Expected shape: (N,6)
    dt_traj = 0.1
    traj_vel, traj_acc = compute_derivatives(traj, dt_traj)
    N = traj.shape[0]
    t_vec = np.linspace(0, dt_traj*(N-1), N)

    # Set initial state to the beginning of the trajectory.
    q_init = traj[0, :]
    
    model, data, model_pin, data_pin = setup_simulation(q_init)
    recorded_data = simulate_and_log(model, data, model_pin, data_pin, t_vec, traj, traj_vel, traj_acc)
    save_logged_data("simulation_data.npz", recorded_data)
    print("Simulation complete.")

if __name__ == "__main__":
    main()