import numpy as np
import matplotlib.pyplot as plt


def plot_angles(data):
    time = data['time']
    joint_pos = data['joint_pos']
    joint_pos_des = data['joint_pos_des']
    n = joint_pos.shape[1]
    fig, axs = plt.subplots(n, 1, figsize=(8, 2*n))
    for i in range(n):
        axs[i].plot(time, joint_pos[:, i], label=f"Joint {i+1} pos", color="C0")
        axs[i].plot(time, joint_pos_des[:, i], label=f"Joint {i+1} des", linestyle="--", color="C1")
        axs[i].set_title(f"Joint {i+1} Position")
        axs[i].set_xlabel("Time (s)")
        axs[i].set_ylabel("Position (rad)")
        axs[i].legend()
        axs[i].grid(True)
    fig.tight_layout()
    plt.show()


def plot_control_components(data):
    time = data['time']
    u_fb = data['u_fb']
    u_ff = data['u_ff']
    u_total = data['u_total']
    n = u_fb.shape[1]
    fig, axs = plt.subplots(n, 1, figsize=(8, 2*n))
    for i in range(n):
        axs[i].plot(time, u_fb[:, i], label="Feedback", color="blue")
        axs[i].plot(time, u_ff[:, i], label="Feedforward", color="green", linestyle="--")
        axs[i].plot(time, u_total[:, i], label="Total", color="purple", linestyle=":")
        axs[i].set_title(f"Control for Joint {i+1}")
        axs[i].set_xlabel("Time (s)")
        axs[i].set_ylabel("Torque (Nm)")
        axs[i].legend()
        axs[i].grid(True)
    fig.tight_layout()
    plt.show()


def plot_tracking_error(data):
    time = data['time']
    joint_pos = data['joint_pos']
    joint_pos_des = data['joint_pos_des']
    joint_vel = data['joint_vel']
    joint_vel_des = data['joint_vel_des']
    n = joint_pos.shape[1]
    
    # Position error plots
    fig1, axs1 = plt.subplots(n, 1, figsize=(8, 2*n))
    for i in range(n):
        pos_error = joint_pos[:, i] - joint_pos_des[:, i]
        axs1[i].plot(time, pos_error, label=f"Joint {i+1} Pos Error", color="red")
        axs1[i].set_title(f"Joint {i+1} Position Error")
        axs1[i].set_xlabel("Time (s)")
        axs1[i].set_ylabel("Error (rad)")
        axs1[i].legend()
        axs1[i].grid(True)
    fig1.tight_layout()
    
    # Velocity error plots
    fig2, axs2 = plt.subplots(n, 1, figsize=(8, 2*n))
    for i in range(n):
        vel_error = joint_vel[:, i] - joint_vel_des[:, i]
        axs2[i].plot(time, vel_error, label=f"Joint {i+1} Vel Error", color="orange")
        axs2[i].set_title(f"Joint {i+1} Velocity Error")
        axs2[i].set_xlabel("Time (s)")
        axs2[i].set_ylabel("Error (rad/s)")
        axs2[i].legend()
        axs2[i].grid(True)
    fig2.tight_layout()

    plt.show()


def plot_velocities(data):
    time = data['time']
    joint_vel = data['joint_vel']
    joint_vel_des = data['joint_vel_des']
    n = joint_vel.shape[1]
    fig, axs = plt.subplots(n, 1, figsize=(8, 2*n))
    for i in range(n):
        axs[i].plot(time, joint_vel[:, i], label=f"Joint {i+1} vel", color="C0")
        axs[i].plot(time, joint_vel_des[:, i], label=f"Joint {i+1} vel des", linestyle="--", color="C1")
        axs[i].set_title(f"Joint {i+1} Velocity")
        axs[i].set_xlabel("Time (s)")
        axs[i].set_ylabel("Velocity (rad/s)")
        axs[i].legend()
        axs[i].grid(True)
    fig.tight_layout()
    plt.show()

def main():
    # Load simulation data from the NPZ file.
    filename = "simulation_data.npz"
    data = np.load(filename)
    
    # Plot joint states vs desired states.
    plot_angles(data)
    
    # Plot joint velocities vs desired velocities
    plot_velocities(data)
    
    # Plot control components (feedback, feedforward and total control)
    plot_control_components(data)
    
    # Plot tracking errors (position and velocity)
    plot_tracking_error(data)

if __name__ == "__main__":
    main()