import mujoco
import numpy as np
import pinocchio as pin
import copy

# --- Create Model and Data ---
model = mujoco.MjModel.from_xml_path("model/ur5e.xml")
data = mujoco.MjData(model)

model_pin = pin.buildModelFromUrdf('model/ur5.urdf')
data_pin = model_pin.createData()

# --- Define a test configuration and velocity using the robot DoF ---
nq = model.nv
q_test = np.full(nq, 0.1)
qdot_test = np.full(nq, 0.2)

# Set MuJoCo state with nonzero velocity, then compute dynamics
data.qpos[:nq] = q_test
data.qvel[:nq] = qdot_test
mujoco.mj_forward(model, data)

# --- MuJoCo Dynamics ---
nq = model.nv
mass_mujoco = np.zeros((nq, nq), dtype=np.float64)
mujoco.mj_fullM(model, mass_mujoco, data.qM)
bias_total_mujoco = data.qfrc_bias.copy()

# Compute gravitational forces in MuJoCo: zero velocities
original_qvel = data.qvel.copy()
data.qvel[:] = 0.0
mujoco.mj_forward(model, data)
gravity_mujoco = data.qfrc_bias.copy()
# Restore original state if needed
data.qvel[:] = original_qvel

coriolis_mujoco = bias_total_mujoco - gravity_mujoco

print('MuJoCo dynamics results:')
print('------------------------')
print('Mass matrix M:')
print(mass_mujoco)
print('\nCombined bias forces (C+G):')
print(bias_total_mujoco)
print('\nGravity G:')
print(gravity_mujoco)
print('\nCoriolis/Centrifugal forces C (bias - gravity):')
print(coriolis_mujoco)

# --- Pinocchio Dynamics ---
# Ensure q and qdot dimensions match the model
q_pin = q_test.copy()
qdot_pin = qdot_test.copy()

# Compute mass matrix using CRBA
mass_pin = pin.crba(model_pin, data_pin, q_pin)
mass_pin = np.array(mass_pin)

# Compute total bias forces (C+G) with nonzero velocities
bias_total_pin = pin.rnea(model_pin, data_pin, q_pin, qdot_pin, np.zeros_like(q_pin))
bias_total_pin = np.array(bias_total_pin)

# Compute gravity using RNEA with zero velocities
gravity_pin = pin.rnea(model_pin, data_pin, q_pin, np.zeros_like(q_pin), np.zeros_like(q_pin))
gravity_pin = np.array(gravity_pin)

coriolis_pin = bias_total_pin - gravity_pin

print('\nPinocchio dynamics results:')
print('---------------------------')
print('Mass matrix M:')
print(mass_pin)
print('\nCombined bias forces (C+G):')
print(bias_total_pin)
print('\nGravity G:')
print(gravity_pin)
print('\nCoriolis/Centrifugal forces C (bias - gravity):')
print(coriolis_pin)

print('\nComparison between MuJoCo and Pinocchio dynamics:')
# Compute differences
diff_mass = mass_mujoco - mass_pin
diff_bias = bias_total_mujoco - bias_total_pin
diff_gravity = gravity_mujoco - gravity_pin
diff_coriolis = coriolis_mujoco - coriolis_pin

print('\nDifference in Mass matrix (MuJoCo - Pinocchio):')
print(diff_mass)
print('\nDifference in Combined bias forces (MuJoCo - Pinocchio):')
print(diff_bias)
print('\nDifference in Gravity forces (MuJoCo - Pinocchio):')
print(diff_gravity)
print('\nDifference in Coriolis forces (MuJoCo - Pinocchio):')
print(diff_coriolis)

