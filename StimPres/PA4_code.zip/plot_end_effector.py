import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d
import pinocchio as pin

# Helper class to create 3D arrows
class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        super().__init__((0,0), (0,0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def do_3d_projection(self, renderer=None):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, self.axes.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        return np.min(zs)

def compute_end_effector_trajectory(joint_trajectory, model_urdf_path='model/ur5e.urdf'):
    """
    Compute end effector positions and orientations given joint trajectories
    
    Args:
        joint_trajectory (np.array): Joint position trajectory (n_timesteps, n_joints)
        model_urdf_path (str): Path to the URDF model file
    
    Returns:
        tuple: (positions, rotations) where:
            positions (np.array): End effector positions (n_timesteps, 3)
            rotations (np.array): End effector rotation matrices (n_timesteps, 3, 3)
    """
    # Load the model and create data
    model = pin.buildModelFromUrdf(model_urdf_path)
    data = pin.Data(model)
    
    # Get frame ID for the attachment site
    attachment_frame_id = None
    for i, frame in enumerate(model.frames):
        if frame.name == "attachment_site":
            attachment_frame_id = i
            break
    
    if attachment_frame_id is None:
        raise ValueError("attachment_site frame not found in the model")
    
    n_timesteps = joint_trajectory.shape[0]
    positions = np.zeros((n_timesteps, 3))
    rotations = np.zeros((n_timesteps, 3, 3))
    
    # Compute forward kinematics for each joint configuration
    for i in range(n_timesteps):
        q = joint_trajectory[i]
        pin.framesForwardKinematics(model, data, q)
        
        # Extract position and orientation of the end effector frame
        positions[i] = data.oMf[attachment_frame_id].translation
        rotations[i] = data.oMf[attachment_frame_id].rotation
    
    return positions, rotations

# Add a new function that computes both actual and desired trajectories
def compute_actual_and_desired_trajectories(actual_joints, desired_joints, model_urdf_path='model/ur5e.urdf'):
    """
    Compute actual and desired end effector trajectories given joint positions
    
    Args:
        actual_joints (np.array): Actual joint positions (n_timesteps, n_joints)
        desired_joints (np.array): Desired joint positions (n_timesteps, n_joints)
        model_urdf_path (str): Path to the URDF model file
    
    Returns:
        tuple: (actual_pos, actual_rot, desired_pos) containing:
            actual_pos (np.array): Actual end effector positions (n_timesteps, 3)
            actual_rot (np.array): Actual end effector rotations (n_timesteps, 3, 3)
            desired_pos (np.array): Desired end effector positions (n_timesteps, 3)
    """
    # Load the model and create data
    model = pin.buildModelFromUrdf(model_urdf_path)
    data = pin.Data(model)
    
    # Get frame ID for the attachment site
    attachment_frame_id = None
    for i, frame in enumerate(model.frames):
        if frame.name == "attachment_site":
            attachment_frame_id = i
            break
    
    if attachment_frame_id is None:
        raise ValueError("attachment_site frame not found in the model")
    
    n_timesteps = actual_joints.shape[0]
    actual_pos = np.zeros((n_timesteps, 3))
    actual_rot = np.zeros((n_timesteps, 3, 3))
    desired_pos = np.zeros((n_timesteps, 3))
    
    # Compute forward kinematics for each configuration
    for i in range(n_timesteps):
        # Actual trajectory
        q_actual = actual_joints[i]
        pin.framesForwardKinematics(model, data, q_actual)
        actual_pos[i] = data.oMf[attachment_frame_id].translation
        actual_rot[i] = data.oMf[attachment_frame_id].rotation
        
        # Desired trajectory (position only)
        q_desired = desired_joints[i]
        pin.framesForwardKinematics(model, data, q_desired)
        desired_pos[i] = data.oMf[attachment_frame_id].translation
    
    return actual_pos, actual_rot, desired_pos

# Update the plotting function to show both trajectories
def plot_end_effector_trajectories(actual_pos, actual_rot, desired_pos, num_frames=8):
    """
    Plot the actual and desired end effector trajectories
    
    Args:
        actual_pos (np.array): Actual end effector positions (n_timesteps, 3)
        actual_rot (np.array): Actual end effector rotations (n_timesteps, 3, 3)
        desired_pos (np.array): Desired end effector positions (n_timesteps, 3)
        num_frames (int): Number of coordinate frames to display
    """
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot both trajectories
    ax.plot(actual_pos[:, 0], actual_pos[:, 1], actual_pos[:, 2], 'b-', linewidth=2, label='Actual Trajectory')
    ax.plot(desired_pos[:, 0], desired_pos[:, 1], desired_pos[:, 2], 'r--', linewidth=2, label='Desired Trajectory')
    
    # Select specific points along the trajectory for showing orientation frames
    n_points = len(actual_pos)
    if num_frames >= n_points:
        frame_indices = range(n_points)
    else:
        frame_indices = [0]  # Always include the first point
        if num_frames > 2:
            # Add intermediate points
            step = (n_points - 1) / (num_frames - 1)
            for i in range(1, num_frames - 1):
                idx = int(i * step)
                frame_indices.append(idx)
        frame_indices.append(n_points - 1)  # Always include the last point
    
    # Draw coordinate frames at selected points
    arrow_length = 0.05  # Length of the arrows
    colors = ['r', 'g', 'b']  # x=red, y=green, z=blue
    
    for i in frame_indices:
        pos = actual_pos[i]
        rot = actual_rot[i]
        
        # Draw coordinate frame axes
        for j in range(3):
            axis = rot[:, j] * arrow_length
            arrow = Arrow3D([pos[0], pos[0] + axis[0]], 
                           [pos[1], pos[1] + axis[1]], 
                           [pos[2], pos[2] + axis[2]],
                           mutation_scale=10, lw=2, arrowstyle='-|>', color=colors[j])
            ax.add_artist(arrow)
        
        # Add a marker at the frame position
        ax.scatter(pos[0], pos[1], pos[2], color='black', s=20)
    
    # Add a coordinate frame legend
    for i, (color, axis) in enumerate(zip(colors, ['X', 'Y', 'Z'])):
        ax.plot([0], [0], [0], color=color, linestyle='-', linewidth=2, label=f'{axis}-axis')
    
    # Set plot properties
    ax.set_xlabel('X [m]')
    ax.set_ylabel('Y [m]')
    ax.set_zlabel('Z [m]')
    ax.set_title('End Effector Trajectories')
    ax.legend()
    
    # Equal aspect ratio
    # Combine both trajectories to get the full range
    all_positions = np.vstack((actual_pos, desired_pos))
    max_range = np.array([
        all_positions[:, 0].max() - all_positions[:, 0].min(),
        all_positions[:, 1].max() - all_positions[:, 1].min(),
        all_positions[:, 2].max() - all_positions[:, 2].min()
    ]).max() / 2.0
    
    mid_x = (all_positions[:, 0].max() + all_positions[:, 0].min()) / 2
    mid_y = (all_positions[:, 1].max() + all_positions[:, 1].min()) / 2
    mid_z = (all_positions[:, 2].max() + all_positions[:, 2].min()) / 2
    
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    
    plt.tight_layout()
    plt.show()

def visualize_end_effector_from_data(data_file='simulation_data.npz', model_path='model/ur5e.urdf', num_frames=8):
    """
    Load simulation data and visualize end effector trajectories
    
    Args:
        data_file (str): Path to simulation data file
        model_path (str): Path to URDF model file
        num_frames (int): Number of orientation frames to show
    """
    # Load data from file
    data = np.load(data_file)
    actual_joints = data['joint_pos']
    desired_joints = data['joint_pos_des']
    
    # Compute actual and desired end effector trajectories
    actual_pos, actual_rot, desired_pos = compute_actual_and_desired_trajectories(
        actual_joints, desired_joints, model_path)
    
    # Plot trajectories
    plot_end_effector_trajectories(actual_pos, actual_rot, desired_pos, num_frames)

if __name__ == "__main__":
    visualize_end_effector_from_data(num_frames=8)  # Show 8 frames
